
<div align="center">
    <img src="assets/youtube_analyzer-logo.png" alt="youtube_analyzer-logo" width="200"/>



![Versão](https://img.shields.io/badge/version-0.2.4-orange)
![Licença](https://img.shields.io/badge/license-MIT-orange)
[![Sponsor](https://img.shields.io/badge/💲Donate-yellow)](https://apoia.se/paulocesar-dev404)

</div>

Obtenha detalhes de vídeos do youtube usando esta lib
---
- [x] Obter detalhes de um vídeo
- [x] obter legendas
- [x] Analizar playlists
- [x] Obter detalhes de uris de Vídeos
- [x] Downloads de audios e vídeos