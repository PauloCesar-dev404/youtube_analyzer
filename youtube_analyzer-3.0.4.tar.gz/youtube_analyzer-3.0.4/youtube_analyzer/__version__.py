__version__ = '3.0.4'
__lib_name__ = 'youtube_analyzer'
__autor__ = 'PauloCesar-dev404'
__repo__ = f'https://github.com/PauloCesar-dev404/{__lib_name__}'
__lib__ = f'https://raw.githubusercontent.com/PauloCesar-dev404/{__lib_name__}/main/{__lib_name__}-{__version__}-py3-none-any.whl'
__source__ = f'https://raw.githubusercontent.com/PauloCesar-dev404/{__lib_name__}/main/{__lib_name__}-{__version__}.tar.gz'

